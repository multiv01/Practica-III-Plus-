/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sudoku;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author Adrián Torralba Gómez
 */
public class Sudoku {

    /**
     * @param args the command line arguments
     */
    
    //MENÚ PRINCIPAL
    public static String menu(){
        Scanner tec = new Scanner(System.in);
        System.out.println("...............................................................");
        System.out.println("Introduce el número de la opción que desees realizar:");
        System.out.println("1- Jugar");
        System.out.println("2- Cambiar la cantidad de números generados al comienzo");
        System.out.println("3- Cargar partida desde fichero");
        System.out.println("4- Salir");
        System.out.println("...............................................................");
        String opcion = tec.nextLine();
        return opcion;
    }
    
    //INTRODUCIR POR TECLADO CASILLA Y NÚMERO O SALIR
    public static String repeticion(){
        Scanner tec = new Scanner(System.in);
        String opcion = "";
        
        System.out.println("...............................................................");
        System.out.println("Introduce la casilla y el número que desees introducir en ella:");
        System.out.println("Ejemplo, Columna A Fila 3 y número 4 sería: \"A3 4\"");
        System.out.println("Introduce \"SALIR\" o \"salir\" si no deseas continuar.");
        System.out.println("Introduce \"REINICIAR\" o \"reiniciar\" si deseas volver a empezar el mismo sudoku.");
        System.out.println("Introduce \"GUARDAR\" o \"guardar\" si deseas guardar la partida del sudoku el sudoku.");
        System.out.println("...............................................................");
        opcion = tec.nextLine();
        return opcion;
    }
    
    //IMPRIMIR SUDOKU - JUGAR
    public static void jugar(int [][] colFil){
        /*VARIABLES*/
        int fil = 1;
        int i;
        int j;
        int cont = 1;
        String posicion = "";
        String lineas = "  -------------------";
        /*
        Las "i" son las filas y las "j" son
        las columnas
        
        Las columnas van de la "a" a la "i",
        las filas van de "1" a "9"
        (Primero se mira la columna y después fila)
        */
        
        System.out.println("  A B C |D E F |G H I");
        System.out.println(lineas);
        
        /*FILA*/
        for(i=0;i<9;i++){
            System.out.print(fil+"|");
            
            /*COMPROBACIÓN*/
            for(j=0;j<9;j++){
                /*
                Si no hay ningún número, es decir 0 
                escribe espacio por pantalla
                */
                posicion = colFil[j][i]+"";
                if(posicion.equals("0")){
                    if(j==8){
                        posicion = " ";
                    }else{
                        posicion = "  ";
                    }
                }else if((posicion != "0")&&(j == 8)){
                    posicion = colFil[j][i]+"";
                }else if(posicion != "0"){
                    posicion = colFil[j][i]+" ";
                }
                
                /*Printear lineas verticales*/
                System.out.print(posicion);
                if(j == 2 || j == 5 || j==8){
                    System.out.print("|");
                }
            }
            
            /*Printear lineas horizontales*/
            if(fil == 3 || fil == 6){
                System.out.println();
                System.out.print("  ");
                while(cont<20){
                    System.out.print("-");
                    cont++;
                }
                cont = 1;
            }
            System.out.println();
            fil++;
        }
        System.out.println(lineas);
        
    }
    
    //GENERAR NÚMEROS ALEATORIOS
    public static int[][] aleatNums(int cantNums, int[][] numsIni){
        /*Nº aleatorio para la posición aleatoria
        de los nºs generados*/
        int pAleatf = 0;
        int pAleatc = 0;
        int nAleat = 0;
        /*Las dos variables son para que,
        pAleatf será un nº aleatorio de fila
        y pAleatc será un nº aleatorio de columna.
        */
        int nCasillas = 0;
        boolean resCompr = false;
        while(nCasillas < cantNums){
            /*
            Mientras nCasillas sea menor o igual a 20
            se hace un bucle que genere números
            aleatorios.
            */
            pAleatf = (int)(Math.random()*9+0);
            pAleatc = (int)(Math.random()*9+0);
            nAleat = (int)(Math.random()*9+1);
            
            /*Si esa posición de la matriz está vacía,
            comprueba para generar número*/ 
            if(numsIni[pAleatc][pAleatf] == 0){
                /*
                SI el número aleatorio generado,
                no esta ni en la fila ni en la columna
                del otro array, entonces se guarda en el array,
                si si que está escribirá 0 en esa posición.
                Todo esto dentro del bucle de <= que 20, para que
                si el número ya está en fila o columna, se genera otro
                número.
                */ 
                resCompr = comprNums(pAleatc, pAleatf, nAleat, numsIni);
            
                if(resCompr == true){
                    numsIni [pAleatc][pAleatf] = nAleat;
                    nCasillas++;
                }
                if(resCompr == false){
                    numsIni [pAleatc][pAleatf] = 0;
                }
            }
        }
        return numsIni;
    }
    
    //GUARDAR PARTIDA EN UN FICHERO
    public static void guardarPartida(int [][] colFil, int [][] numsIni){
        Scanner tec = new Scanner(System.in);
        String nombre = "";
        String nPartida = "";
        int i,j;
        //Guardar el sudoku
        System.out.println("-----------------------------------------------");
        System.out.println("--     G U A R D A R   E L   S U D O K U     --");
        System.out.println("-----------------------------------------------");
        System.out.println();
        System.out.println("Introduce el nombre con el que desees que se guarde la partida:");
        System.out.println("(La partida se guardará automáticamente en la carpeta \"saves\", introduce solo el nombre)");
        nombre = tec.nextLine();
        nPartida = ".\\saves\\"+nombre;
        FileWriter fw = null;
        BufferedWriter bw = null;
        try{
            fw = new FileWriter(nPartida);
            bw = new BufferedWriter(fw);
            //Escribir fila por fila en el fichero (colFil)
            for(j=0;j < colFil.length; j++){
                for(i=0;i < colFil[j].length; i++){
                    bw.write(colFil[i][j]+"");
                }
                bw.write("\n");
            }
            //Escribir fila por fila en el fichero (numsIni)
            for(j=0;j < numsIni.length; j++){
                for(i=0;i < numsIni[j].length; i++){
                    bw.write(numsIni[i][j]+"");
                }
                bw.write("\n");
            }
        } catch (Exception e){
            //EN CASO DE ERROR MOSTRARLO
            System.out.println("Error de escritura del fichero");
            System.out.println(e.getMessage());
        } finally {
            try {
                //CERRAR FICHERO
                if(bw != null){
                    bw.close();
                }
                System.out.println("Fichero guardado correctamente");
            } catch (Exception e){
                System.out.println("Error al cerrar el fichero");
                System.out.println(e.toString());
            }
        }
    System.out.println("...............................................");
    System.out.println("-----------------------------------------------"); 
    }
    
    //COMPROBAR NÚMERO CON COLUMNA Y FILA
    public static boolean comprNums(int columna, int fila, int numero, int [][] colFil){
        int i, j;
        /*filaLibre y colLibre servirán para verificar si en el bucle
        de esa fila y columna no está el número.
        filaNoLibre y colNoLibre sirve para cuando SÍ está el número
        e imprime que ya existe en esa fila*/
        boolean filaNoLibre = false;
        boolean colNoLibre = false;
        boolean cuadNoLibre = false;
        /*Inicio y fin de la fila y la columna*/
        int fInicio = 0;
        int fFin = 0;
        int cInicio = 0;
        int cFin = 0;
        /*Este será el resultado que devolverá este método,
        si es posible introducir ese número en esa casilla o no*/
        boolean posible = false;
        
        /*Comprobar la fila*/
        for(i=0;i<colFil.length-1;i++){
            /*Si posición en i == numero*/
            if(colFil[columna][i] == numero){
                colNoLibre = true;
            }
        }
        
        /*Comprobar la columna*/
        for(j=0;j<colFil.length-1;j++){
            /*Si posición en j == numero*/
            if(colFil[j][fila] == numero){
                filaNoLibre = true;
            }
        }
        
        /*-- C O M P R O B A R  C U A D R A N T E --*/
        /*-- FILAS --*/
        /*Primera fila (si la fila es 0, 1 o 2)*/
        if(fila >= 0 && fila<=2){
            /*Si es así, la fila
            empieza en 0 y acaba en 2*/
            fInicio = 0;
            fFin = 2;
        }
        
        /*Segunda fila (si la fila es 3, 4 o 5)*/
        if(fila >= 3 && fila<=5){
            /*Si es así, la fila
            empieza en 3 y acaba en 5*/
            fInicio = 3;
            fFin = 5;
        }
        
        /*Tercera fila (si la fila es 6, 7 o 8)*/
        if(fila >= 6 && fila<=8){
            /*Si es así, la fila
            empieza en 6 y acaba en 8*/
            fInicio = 6;
            fFin = 8;
        }
        
        
        /*-- COLUMNAS --*/
        /*Primera columna (si la columna es 0, 1 o 2)*/
        if(columna >= 0 && columna<=2){
            /*Si es así, la columna
            empieza en 0 y acaba en 2*/
            cInicio = 0;
            cFin = 2;
        }
        
        /*Segunda columna (si la fila es 3, 4 o 5)*/
        if(columna >= 3 && columna<=5){
            /*Si es así, la columna
            empieza en 3 y acaba en 5*/
            cInicio = 3;
            cFin = 5;
        }
        
        /*Tercera columna (si la fila es 6, 7 o 8)*/
        if(columna >= 6 && columna<=8){
            /*Si es así, la columna
            empieza en 6 y acaba en 8*/
            cInicio = 6;
            cFin = 8;
        }
        /*Desde el inicio de la columna hasta el final*/
        for(j=cInicio; j <= cFin; j++){
            /*Desde el inicio de la fila hasta el final*/
            for(i=fInicio; i <= fFin; i++){
                /*Si posición en j == numero*/
                if(colFil[j][i] == numero){
                    cuadNoLibre = true;
                }
            }
        }
        
        /*Si la fila o la columna no están libres, es decir,
        en una de las dos ya hay o una fila o una columna que
        tiene el número, entonces devolverá que "posible" es false
        ya que no se puede introducir el número en esa casilla al ya
        existir en alguna fila, columna o cuadrante*/
        if((filaNoLibre == true)||(colNoLibre == true)||(cuadNoLibre == true)){
            posible = false;
        }
        /*Si tanto fila como columna están libres entonces devuelve
        "posible" es true, de esta forma SÍ se podrá introducir el número
        en esa casilla
        fialNoLibre == false --> La fila está libre
        colNoLibre == false --> La columna está libre
        cuadNoLibre == false --> El cuadrante está libre
        */
        if((filaNoLibre == false)&&(colNoLibre == false)&&(cuadNoLibre == false)){
            posible = true;
        }
        
        return posible;
    }
    
    
    
    /*PROGRAMA*/
    public static void main(String[] args) {
        Scanner tec = new Scanner(System.in);
        System.out.println("-----------------------------");
        System.out.println("|        S U D O K U        |");
        System.out.println("-----------------------------");
        
        /*VARIABLES*/
        String repeText = "";
        String opcion = "";
        boolean salir = false;
        int [][] colFil = new int [9][9];
        //Array con los números generados al inicio
        int [][] numsIni = new int [9][9];
        int cantNums = 20;
        /*COMPROBACIÓN DE LA REPETICIÓN*/
        char [] letrasMay = {'A','B','C','D','E','F','G','H','I'};
        char [] letrasMin = {'a','b','c','d','e','f','g','h','i'};
        char [] numeros = {'1','2','3','4','5','6','7','8','9'};
        boolean aparecec = false;
        boolean aparecef = false;
        boolean aparecen = false;
        char caract1 = ' ';
        char caract2 = ' ';
        char caract3 = ' ';
        char espacio = ' ';
        int longiText = 0;
        int i, j, k;
        String malEscrito = "El texto introducido es erróneo, debe ser como en el ejemplo y con el espacio de separación.";
        int nBusc = 0;
        int filaBusc = 0;
        int colBusc = 0;
        int fil = 0;
        int col = 0;
        int filArreglo = 0;
        int colArreglo = 0;
        String numero = "";
        int n = 0;
        int num = 0;
        String nPartida = "";
        String nombre = "";
        boolean posible = false;
        /*coinNIni es true si coinciden la posición 
        del número que se quiere introducir con
        que haya algún número ahí, por tanto, no se podrá introducir*/
        boolean coinNIni = false;
        boolean hayAlgunCero = false;
        boolean cargado = false;
        
        do{
            /*Menú*/
            opcion = menu();
            /*OPCIÓN 3*/
            if(opcion.equalsIgnoreCase("3")){
                //Guardar el sudoku
                System.out.println("---------------------------------------------");
                System.out.println("--     C A R G A R   E L   S U D O K U     --");
                System.out.println("---------------------------------------------");
                System.out.println();
                System.out.println("Introduce el nombre del fichero del que desees que se restaure la partida:");
                System.out.println("(Recuarda que el fichero debe encontrarse en la carpeta \"saves\")");
                nombre = tec.nextLine();
                nPartida = ".\\saves\\"+nombre;
                FileReader fr = null;
                BufferedReader br = null;
                String linea = "";
                try{
                    /*ABRIR FICHERO*/
                    fr = new FileReader(nPartida);
                    br = new BufferedReader(fr);
                    /*LEER PRIMER CARACTER, SE DEBE ALMACENAR EN VARIABLE TIPO INT*/
                    linea = br.readLine();
                    //Para el array colFil
                    for(j=0;j < colFil.length; j++){
                        for(i=0;i < colFil[j].length; i++){
                            n = linea.charAt(i);
                            colFil[i][j] = n;
                        }
                        linea = br.readLine();
                    }
                    //Para el array numsIni
                    for(j=0;j < numsIni.length; j++){
                        for(i=0;i < numsIni[j].length; i++){
                            n = linea.charAt(i);
                            numsIni[i][j] = n;
                        }
                        linea = br.readLine();
                    }
                }catch (FileNotFoundException e){
                    /*EN CASO DE NO ENCONTRAR EL FICHERO*/
                    System.out.println("Error: Fichero no encontrado");
                    System.out.println(e.getMessage());
                }catch (Exception e){
                    /*EN CASO DE ERROR GENERAL*/
                    System.out.println("Error de lectura del fichero");
                    System.out.println(e.getMessage());
                } finally {
                    /*EN CASO DE QUE HAYA O NO ERROR*/
                    try {
                        /*CERRAR FICHERO*/
                        if(br != null){
                            br.close();
                        }
                    } catch (Exception e){
                        System.out.println("Error al cerrar el fichero");
                        System.out.println(e.toString());
                    }
                }
                cargado = true;
                System.out.println("...............................................");
                System.out.println("-----------------------------------------------");    
            }
            
            /*JUGAR*/
            if(opcion.equalsIgnoreCase("1")){
                if(cargado == false){
                    /*Cantidad de números generados en el comienzo*/
                    numsIni = aleatNums(cantNums,numsIni);
                    for(i=0;i<colFil.length;i++){
                        for(j=0;j<colFil.length;j++){
                            colFil [j][i] = numsIni [j][i];
                        }
                    }    
                }
                
                System.out.println("---------------------------");
                System.out.println("|        J U E G O        |");
                System.out.println("---------------------------");

                do{
                    System.out.println("...............................................................");
                    jugar(colFil);
                    repeText = repeticion();
                    /*-- REINICIAR EL SUDOKU --*/
                    if(repeText.equalsIgnoreCase("REINICIAR")){
                        System.out.println("Reiniciando el sudoku...");
                        //Establecer todo el array a 0
                        for(j=0;j<colFil.length;j++){
                            for(i=0;i<colFil.length;i++){
                                colFil[j][i] = 0;
                            }
                        }
                        //Establecer todo el array con los valores de inicio
                        for(j=0;j<colFil.length;j++){
                            for(i=0;i<colFil.length;i++){
                                colFil[j][i] = numsIni[j][i];
                            }
                        }
                        
                    }else if(repeText.equalsIgnoreCase("GUARDAR")){
                        guardarPartida(colFil,numsIni);
                    }else if(repeText.equalsIgnoreCase("SALIR")){
                        /*-- SALIR DEL PROGRAMA --*/
                        System.out.println("saliendo...");
                        salir = true;
                    }else{
                        /*Comprobar si todas las casillas están llenas*/
                        for(j=0;j<colFil.length-1;j++){
                            for(i=0;i<colFil.length-1;i++){
                                /*Si alguna casilla es 0
                                hayAlgunCero será true*/
                                if(colFil[j][i] == 0){
                                    hayAlgunCero = true;
                                }
                            }
                        }
                        if(hayAlgunCero == true){
                            longiText = repeText.length();
                            if(longiText == 4){
                                /*-- COMPROBAR EL TEXTO INTRODUCIDO --*/

                                /*Primer carácter (0)- Letra (Columna)*/
                                caract1 = repeText.charAt(0);
                                /*Segundo carácter (1) - Fila*/
                                caract2 = repeText.charAt(1);
                                /*Espacio (2)*/
                                espacio = repeText.charAt(2);
                                /*Tercer carácter (3) - Número que se quiere introducir*/
                                caract3 = repeText.charAt(3);
                                numero = caract3+"";
                                num = Integer.parseInt(numero);
                                /*Longitud de texto, para que concuerde con el ejemplo*/
                                
                                /*Si no existe el espacio está mal escrito*/
                                if(espacio != ' '){
                                    System.out.println(malEscrito);
                                }else{
                                    /*Si el espacio si existe*/
                                    
                                    /*Comprobación columna -- Letras mayúsculas y minúsculas*/
                                    for (j = 0; j < letrasMay.length; j++) {
                                        if((caract1 == letrasMay[j])||(caract1 == letrasMin[j])){
                                            aparecec = true;
                                            col = j;
                                        }
                                    }
                                    /*
                                    Si en la posición de i
                                    aparece el primer carácter 
                                    de teclado devuelve true
                                    */
                                    if((aparecec == true) && (longiText == 4)){
                                        System.out.println("La letra "+caract1+" es correcta");
                                        /*
                                        Si aparece la primera letra,
                                        se comprueba si el número
                                        que va detrás de la letra
                                        está entre 1 y 9, es decir,
                                        corresponde con las filas
                                        */
                                        /*Comprobación fila*/
                                        for (i = 0; i < numeros.length; i++){
                                            if(caract2 == numeros[i]){
                                                aparecef = true;
                                                fil = i;
                                            }
                                        }
                                        if(aparecef == true){
                                            System.out.println("La fila "+caract2+" es correcta");
                                            /*
                                            Si aparece el número de fila, se comprueba si
                                            el número que se va a introducir está entre
                                            1 y 9, es decir, corresponde con el array de 
                                            las filas, ya que los números que se pueden
                                            introducir son los mismos que las filas,
                                            del 1 al 9
                                            */
                                            /*Comprobación número
                                            que se desea introducir*/
                                            for (k = 0; k < numeros.length; k++){
                                                if(caract3 == numeros[k]){
                                                    aparecen = true;
                                                    nBusc = num;
                                                }
                                            }
                                            if(aparecen == true){
                                                System.out.println("El número "+caract3+" es correcto");

                                                /*
                                                SI TODO ES CORRECTO
                                                SE COMPRUEBA SI SE
                                                PUEDE INTRODUCIR EN
                                                ESA CASILLA Y SE 
                                                INTRODUCE

                                                Se van a buscar:
                                                nBusc--> Nº que se quiere buscar
                                                filaBusc--> Fila que se quiere buscar
                                                colBusc--> Columna que se quiere buscar
                                                */
                                                colBusc = col;
                                                filaBusc = fil;
                                                posible = comprNums(colBusc,filaBusc,nBusc,colFil);
                                                
                                                //coinNIni
                                                /*
                                                Para que al empezar el array en 0,
                                                se guarde el número en la posición
                                                correcta
                                                */
                                                filArreglo = filaBusc;
                                                colArreglo = colBusc;
                                                
                                                //Comprobación con el array del inicio
                                                if(numsIni[colArreglo][filArreglo] != 0){
                                                    coinNIni = true;
                                                }else if (numsIni[colArreglo][filArreglo] == 0){
                                                    coinNIni = false;
                                                }
                                                
                                                /*Si se puede introducir el número en esa casilla*/
                                                if((posible == true)&&(coinNIni == false)){
                                                    /*Si se puede introducir el número en esa casilla*/
                                                    colFil[colArreglo][filArreglo] = nBusc;
                                                    System.out.println("Número introducido correctamente");
                                                }else if((posible == false)||(coinNIni == true)){
                                                    /*Si no se puede*/
                                                    System.out.println("El número introducido es erróneo por alguna de las siguientes razones:");
                                                    System.out.println(" - El número introducido pertenece a los generados al inicio del sudoku.");
                                                    System.out.println(" - El número introducido ya existe en la misma fila, columna o cuadrante.");
                                                    System.out.println("Prueba de nuevo introduciendo otro número");
                                                }
                                            }
                                        }else{
                                            System.out.println("La fila no corresponde con ninguna del sudoku");
                                        }
                                    }else{
                                        System.out.println("La columna introducida no corresponde con las del sudoku");
                                    }
                                }
                            }else{
                                System.out.println(malEscrito);
                            }
                        }else if(hayAlgunCero == false){
                            System.out.println("¡¡¡Has completado el sudoku!!!");
                            System.out.println("¡¡¡  F E L I C I D A D E S  !!!");
                            salir = true;
                        }
                    }
                }while(salir == false);
            }
            /*OPCIÓN 2*/
            if(opcion.equalsIgnoreCase("2")){
                System.out.println("----------------------------------------------------");
                System.out.println("Cambiar la cantidad de números generados al comienzo");
                System.out.println("----------------------------------------------------");
                System.out.println();
                System.out.println("Introduce la cantidad de números que se generarán (valor por defecto 20) :");
                cantNums = tec.nextInt();
                System.out.println("Se ha modificado correctamente la cantidad de números.");
            }
            
            /*SALIR*/
            if(opcion.equalsIgnoreCase("4")){
                System.out.println("Saliendo...");
            }
        }while(salir == false);
        // TODO code application logic here
    }    
}
